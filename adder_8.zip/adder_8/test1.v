module test1;

    // Inputs
    reg [7:0] a;
    reg [7:0] b;
    reg cin;

    // Outputs
    wire [7:0] s;
    wire cout;
	 // Instantiate the Unit Under Test (UUT)
    Add8 uut (
        .s(s), 
        .cout(cout), 
        .a(a), 
        .b(b), 
        .cin(cin)
    );

    initial begin
        // Initialize Inputs
        a = 8'd0;
        b = 8'd0;
        cin = 0;

        // Wait 100 ns for global reset to finish
        #100;
		  // Test Case 1: 15 + 10 = 25
        a = 8'd15;
        b = 8'd10;
        cin = 0;
        #100;

        // Test Case 2: 255 + 1 = 256 (Carry Out = 1, Sum = 0)
        a = 8'd255;
        b = 8'd1;
        cin = 0;
        #100;

        // Test Case 3: 50 + 20 + 1 (cin) = 71
        a = 8'd50;
        b = 8'd20;
        cin = 1;
        #100;

        $finish;
    end
      
endmodule